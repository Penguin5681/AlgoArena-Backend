create function insert_user_total_xp() returns trigger
    language plpgsql
as
$$BEGIN
  INSERT INTO user_total_xp (user_id, email, total_xp)
  VALUES (NEW.id, NEW.email, 0);
  RETURN NEW;
END;$$;

alter function insert_user_total_xp() owner to penguin;

