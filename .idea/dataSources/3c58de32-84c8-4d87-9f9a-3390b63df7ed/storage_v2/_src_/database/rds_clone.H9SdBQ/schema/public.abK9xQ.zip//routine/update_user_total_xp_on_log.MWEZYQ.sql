create function update_user_total_xp_on_log() returns trigger
    language plpgsql
as
$$
BEGIN
  UPDATE user_total_xp
  SET total_xp = total_xp + NEW.xp_earned
  WHERE user_id = NEW.user_id;
  RETURN NEW;
END;
$$;

alter function update_user_total_xp_on_log() owner to penguin;

